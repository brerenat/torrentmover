#!/bin/sh -
nohup java -jar torrentmover.jar &
